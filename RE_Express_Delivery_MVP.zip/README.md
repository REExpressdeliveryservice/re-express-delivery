# R.E Express Delivery Service — MVP

A mobile-friendly installable web app prototype for Tepa.

## Included
- Customer delivery request form
- Food, groceries, parcels, documents, clothing and other categories
- Estimated delivery fee
- Cash or Mobile Money selection
- Rider dashboard with accept/reject and status progression
- Admin dashboard with order count and recorded fees
- Local device storage for demo orders
- PWA manifest and app icon

## Important
This is a functional MVP/prototype, not yet a production multi-user delivery platform. Production needs a hosted backend/database, authentication, real-time rider matching, GPS/maps, secure MoMo integration, push notifications, and deployment to Google Play.

## Run
Open `index.html` in a browser. For PWA installation and full service-worker behavior, host the folder on HTTPS.
