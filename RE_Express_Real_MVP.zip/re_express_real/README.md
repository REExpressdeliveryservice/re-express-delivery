# R.E Express Delivery Service — Real MVP

A mobile-friendly Tepa delivery web app prototype with customer ordering, rider workflow, admin dashboard, delivery pricing, and Cash/MoMo selection.

## Run
Open `index.html` in a browser.

## Important
This version stores orders locally in the browser. It is not yet a multi-device production backend. For production, connect a hosted database/authentication service, GPS/maps, push notifications, and Ghana MoMo payment API before public launch.
