# R.E Express Delivery Service — Deployment Package

This package is ready to upload to a static web host.

## Included
- Customer delivery request form
- Rider delivery-status workflow
- Admin order dashboard
- Cash / MoMo selection
- Responsive mobile design
- PWA manifest
- Basic SPA redirect configuration

## Important production note
The current app stores orders in the browser with `localStorage`. That means it is suitable for a demo/static launch, but customer, rider and admin data are NOT shared between different phones.

Before operating publicly with real customer data, connect:
1. Hosted authentication
2. Cloud database
3. Server-side order API
4. GPS/maps service
5. Push/SMS notifications
6. Ghana Mobile Money payment gateway
7. Admin authentication and authorization

## Static deployment
Upload the contents of this folder to a static hosting provider. The site entry point is `index.html`.

## Test locally
Open `index.html` in a modern browser, or serve the folder with any simple static HTTP server.

## Brand
R.E Express Delivery Service
Area: Tepa
Service: Motorcycle delivery of legal, safe items that the motorcycle can carry
Payments: Cash and MoMo
