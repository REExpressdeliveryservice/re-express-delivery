import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import pg from 'pg';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();
const {Pool}=pg;
const app=express();
const pool=new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.DATABASE_URL?.includes('localhost')?false:{rejectUnauthorized:false}});
app.use(cors({origin:process.env.CORS_ORIGIN||true}));
app.use(express.json());
const __dirname=path.dirname(fileURLToPath(import.meta.url));
app.use(express.static(path.join(__dirname,'..','public')));

const sign=u=>jwt.sign({id:u.id,role:u.role,name:u.name,phone:u.phone},process.env.JWT_SECRET,{expiresIn:'7d'});
function auth(req,res,next){try{const h=req.headers.authorization||'';if(!h.startsWith('Bearer '))throw Error();req.user=jwt.verify(h.slice(7),process.env.JWT_SECRET);next()}catch{res.status(401).json({error:'Authentication required'})}}
const role=r=>(req,res,next)=>req.user?.role===r?next():res.status(403).json({error:'Not authorized'});
const fee=km=>Math.max(10,10+Math.ceil(Number(km||1))*3);
const code=()=>`RE-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;

app.get('/api/health',(req,res)=>res.json({ok:true,service:'R.E Express',area:'Tepa'}));
app.post('/api/auth/register',async(req,res)=>{try{const {name,phone,password,role='customer'}=req.body;if(!name||!phone||!password)return res.status(400).json({error:'Name, phone and password are required'});if(!['customer','rider'].includes(role))return res.status(400).json({error:'Invalid role'});const hash=await bcrypt.hash(password,12);const q=await pool.query('INSERT INTO users(name,phone,password_hash,role) VALUES($1,$2,$3,$4) RETURNING id,name,phone,role',[name,phone,hash,role]);res.status(201).json({user:q.rows[0],token:sign(q.rows[0])})}catch(e){res.status(400).json({error:e.code==='23505'?'Phone number already registered':'Registration failed'})}});
app.post('/api/auth/login',async(req,res)=>{try{const {phone,password}=req.body;const q=await pool.query('SELECT * FROM users WHERE phone=$1 AND active=true',[phone]);if(!q.rows[0]||!(await bcrypt.compare(password,q.rows[0].password_hash)))return res.status(401).json({error:'Invalid phone or password'});const u=q.rows[0];res.json({user:{id:u.id,name:u.name,phone:u.phone,role:u.role},token:sign(u)})}catch{res.status(500).json({error:'Login failed'})}});
app.post('/api/orders',auth,role('customer'),async(req,res)=>{try{const {pickup,dropoff,item_type,item_description,distance_km,payment_method,notes}=req.body;if(!pickup||!dropoff||!item_type)return res.status(400).json({error:'Pickup, drop-off and item type are required'});const km=Number(distance_km||1);const q=await pool.query('INSERT INTO orders(code,customer_id,pickup,dropoff,item_type,item_description,distance_km,fee,payment_method,notes) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *',[code(),req.user.id,pickup,dropoff,item_type,item_description,km,fee(km),payment_method||'cash',notes||null]);res.status(201).json(q.rows[0])}catch(e){res.status(500).json({error:'Could not create order'})}});
app.get('/api/orders',auth,async(req,res)=>{try{let q;if(req.user.role==='customer')q=await pool.query('SELECT o.*,u.name customer_name,u.phone customer_phone FROM orders o JOIN users u ON u.id=o.customer_id WHERE customer_id=$1 ORDER BY o.created_at DESC',[req.user.id]);else if(req.user.role==='rider')q=await pool.query("SELECT o.*,u.name customer_name,u.phone customer_phone FROM orders o JOIN users u ON u.id=o.customer_id WHERE o.status='pending' OR o.rider_id=$1 ORDER BY o.created_at DESC",[req.user.id]);else q=await pool.query('SELECT o.*,c.name customer_name,c.phone customer_phone,r.name rider_name FROM orders o JOIN users c ON c.id=o.customer_id LEFT JOIN users r ON r.id=o.rider_id ORDER BY o.created_at DESC');res.json(q.rows)}catch{res.status(500).json({error:'Could not load orders'})}});
app.patch('/api/orders/:id/accept',auth,role('rider'),async(req,res)=>{const q=await pool.query("UPDATE orders SET rider_id=$1,status='accepted',updated_at=NOW() WHERE id=$2 AND status='pending' RETURNING *",[req.user.id,req.params.id]);res.status(q.rowCount?200:409).json(q.rowCount?q.rows[0]:{error:'Order no longer available'})});
app.patch('/api/orders/:id/status',auth,async(req,res)=>{const allowed=['accepted','picked_up','on_the_way','delivered','cancelled'];const s=req.body.status;if(!allowed.includes(s))return res.status(400).json({error:'Invalid status'});const q=await pool.query('UPDATE orders SET status=$1,updated_at=NOW() WHERE id=$2 AND (customer_id=$3 OR rider_id=$3 OR $4=$5) RETURNING *',[s,req.params.id,req.user.id,req.user.role,'admin']);res.status(q.rowCount?200:404).json(q.rowCount?q.rows[0]:{error:'Order not found or not authorized'})});
app.get('/api/admin/stats',auth,role('admin'),async(req,res)=>{const q=await pool.query("SELECT COUNT(*) total_orders,COUNT(*) FILTER(WHERE status='delivered') delivered,COALESCE(SUM(fee) FILTER(WHERE status='delivered'),0) earnings FROM orders");res.json(q.rows[0])});
app.get('/api/riders',auth,role('admin'),async(req,res)=>res.json((await pool.query("SELECT id,name,phone,active,created_at FROM users WHERE role='rider' ORDER BY created_at DESC")).rows));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'..','public','index.html')));
app.listen(process.env.PORT||3000,()=>console.log(`R.E Express running on port ${process.env.PORT||3000}`));
