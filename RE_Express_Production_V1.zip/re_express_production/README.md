# R.E Express Delivery Service — Production Backend Starter

This version replaces browser-only localStorage with a PostgreSQL-backed API and JWT authentication.

## Includes
- Customer and rider registration/login
- Admin role support
- Cloud-database-ready orders
- Rider order acceptance
- Delivery status workflow
- Admin statistics
- Cash and MoMo payment method fields
- Mobile-friendly web interface
- Docker deployment file

## Required before public launch
1. Create a managed PostgreSQL database.
2. Set `DATABASE_URL` and a strong `JWT_SECRET`.
3. Run `server/schema.sql` against the database.
4. Create the first admin account securely (for example via a controlled SQL/admin script; do not expose admin registration publicly).
5. Add a real Ghana MoMo payment provider/API and server-side payment verification.
6. Add Google Maps/Mapbox or another mapping provider for address selection and GPS tracking.
7. Add push/SMS notifications.
8. Add HTTPS and production CORS settings.
9. Add rate limiting, request validation, audit logs, backups and monitoring.

## Local test
```bash
cp .env.example .env
npm install
# configure DATABASE_URL and JWT_SECRET in .env
npm start
```
Open http://localhost:3000

This package is a production-oriented foundation, not a claim that the service is already hosted or that payment/GPS integrations are live.
